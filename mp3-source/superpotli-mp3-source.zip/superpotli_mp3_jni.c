/*
 * SuperPotli MP3 bridge: connects the app (Kotlin object Mp3Lame) to the LAME 3.100 encoder.
 *
 * Copyright (c) 2026 S Projects. Licensed under the GNU Lesser General Public License, version 2 or later,
 * the same terms as LAME (see COPYING.LGPL in this folder). This file together with LAME 3.100 is built into ONE shared
 * library, libsuperpotli_mp3.so, by build-android.sh. Re-created 2026-11-26 from the interface the shipped library had
 * (four JNI functions used by app/src/main/java/com/scrafttools/android/feature/media/audio/Mp3Lame.kt and AudioEngine.encodeMp3).
 *
 * Kotlin side (object Mp3Lame, all @JvmStatic external):
 *   nativeInit(rate: Int, channels: Int, kbps: Int): Long            -> encoder handle, 0 on failure
 *   nativeEncode(handle: Long, pcm: ShortArray, frames: Int, channels: Int): ByteArray?   -> MP3 bytes, null on failure
 *   nativeFlush(handle: Long): ByteArray                              -> last MP3 bytes
 *   nativeClose(handle: Long)
 * pcm holds `frames` sample frames, interleaved when channels == 2. Output is constant bitrate.
 *
 * The plain C functions sp_mp3_* below hold all the logic and are exported so that a small test program can call them
 * without a Java runtime (see test_sp_mp3.c).
 */
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include "lame.h"

#define SP_EXPORT __attribute__((visibility("default")))

typedef struct {
    lame_t gfp;
    int channels;
} SpMp3;

/* Returns an encoder or NULL. channels: 1 = mono, anything else = stereo. */
SP_EXPORT SpMp3 *sp_mp3_open(int rate, int channels, int kbps) {
    if (rate < 8000 || rate > 48000 || kbps < 8 || kbps > 320) return NULL;
    SpMp3 *e = (SpMp3 *)calloc(1, sizeof(SpMp3));
    if (!e) return NULL;
    e->gfp = lame_init();
    if (!e->gfp) { free(e); return NULL; }
    e->channels = (channels == 1) ? 1 : 2;
    lame_set_in_samplerate(e->gfp, rate);
    lame_set_num_channels(e->gfp, e->channels);
    lame_set_mode(e->gfp, e->channels == 1 ? MONO : JOINT_STEREO);
    lame_set_brate(e->gfp, kbps);
    lame_set_VBR(e->gfp, vbr_off);
    lame_set_quality(e->gfp, 2);
    if (lame_init_params(e->gfp) < 0) { lame_close(e->gfp); free(e); return NULL; }
    return e;
}

/* Encodes `frames` frames. Writes to out (capacity out_cap). Returns bytes written, or -1 on error. */
SP_EXPORT int sp_mp3_encode(SpMp3 *e, const short *pcm, int frames, unsigned char *out, int out_cap) {
    if (!e || !pcm || frames < 0) return -1;
    if (frames == 0) return 0;
    int n = (e->channels == 1)
        ? lame_encode_buffer(e->gfp, pcm, NULL, frames, out, out_cap)
        : lame_encode_buffer_interleaved(e->gfp, (short *)pcm, frames, out, out_cap);
    return n < 0 ? -1 : n;
}

SP_EXPORT int sp_mp3_flush(SpMp3 *e, unsigned char *out, int out_cap) {
    if (!e) return -1;
    int n = lame_encode_flush(e->gfp, out, out_cap);
    return n < 0 ? -1 : n;
}

SP_EXPORT void sp_mp3_close(SpMp3 *e) {
    if (!e) return;
    lame_close(e->gfp);
    free(e);
}

/* LAME's documented worst case for the output buffer: 1.25 * samples + 7200. */
static int out_capacity(int frames) { return (int)(1.25 * (double)frames + 7200.0) + 1024; }

#define JNI(name) Java_com_scrafttools_android_feature_media_audio_Mp3Lame_##name

JNIEXPORT jlong JNICALL JNI(nativeInit)(JNIEnv *env, jclass cls, jint rate, jint channels, jint kbps) {
    (void)env; (void)cls;
    return (jlong)(intptr_t)sp_mp3_open(rate, channels, kbps);
}

JNIEXPORT jbyteArray JNICALL JNI(nativeEncode)(JNIEnv *env, jclass cls, jlong handle, jshortArray pcm, jint frames, jint channels) {
    (void)cls;
    SpMp3 *e = (SpMp3 *)(intptr_t)handle;
    if (!e || !pcm || frames < 0) return NULL;
    int ch = (channels == 1) ? 1 : 2;
    if (ch != e->channels) return NULL;
    if ((*env)->GetArrayLength(env, pcm) < frames * ch) return NULL;
    int cap = out_capacity(frames);
    unsigned char *buf = (unsigned char *)malloc((size_t)cap);
    if (!buf) return NULL;
    jshort *samples = (*env)->GetShortArrayElements(env, pcm, NULL);
    if (!samples) { free(buf); return NULL; }
    int n = sp_mp3_encode(e, samples, frames, buf, cap);
    (*env)->ReleaseShortArrayElements(env, pcm, samples, JNI_ABORT);
    jbyteArray result = NULL;
    if (n >= 0) {
        result = (*env)->NewByteArray(env, n);
        if (result && n > 0) (*env)->SetByteArrayRegion(env, result, 0, n, (const jbyte *)buf);
    }
    free(buf);
    return result;
}

JNIEXPORT jbyteArray JNICALL JNI(nativeFlush)(JNIEnv *env, jclass cls, jlong handle) {
    (void)cls;
    SpMp3 *e = (SpMp3 *)(intptr_t)handle;
    unsigned char buf[8192];
    int n = e ? sp_mp3_flush(e, buf, (int)sizeof(buf)) : 0;
    if (n < 0) n = 0;
    jbyteArray result = (*env)->NewByteArray(env, n);
    if (result && n > 0) (*env)->SetByteArrayRegion(env, result, 0, n, (const jbyte *)buf);
    return result;
}

JNIEXPORT void JNICALL JNI(nativeClose)(JNIEnv *env, jclass cls, jlong handle) {
    (void)env; (void)cls;
    sp_mp3_close((SpMp3 *)(intptr_t)handle);
}
