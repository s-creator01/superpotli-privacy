#!/usr/bin/env bash
# Rebuilds libsuperpotli_mp3.so (LAME 3.100 + superpotli_mp3_jni.c) for arm64-v8a and x86_64.
# Needs only: the Android NDK (r28 used), tar, shasum. Nothing is downloaded: LAME 3.100 is in source/lame-3.100.tar.gz.
# Usage:  engine/mp3/build-android.sh            builds into engine/mp3/out/<abi>/libsuperpotli_mp3.so
#         engine/mp3/build-android.sh host       builds a Mac/Linux test copy into engine/mp3/out/host/ (for test_sp_mp3.c)
# The same 16 KB page alignment as the other native libraries is applied (Google Play rule for 64-bit libraries).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
NDK="${ANDROID_NDK_HOME:-$({ ls -d "$HOME"/Library/Android/sdk/ndk/* "$HOME"/Android/Sdk/ndk/* 2>/dev/null || true; } | tail -1)}"
[ -d "$NDK" ] || { echo "Android NDK not found (set ANDROID_NDK_HOME)"; exit 1; }
TOOLS="$(ls -d "$NDK"/toolchains/llvm/prebuilt/*)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
(cd "$HERE/source" && shasum -a 256 -c lame-3.100.tar.gz.sha256)
tar -xzf "$HERE/source/lame-3.100.tar.gz" -C "$WORK"
SRC="$WORK"
# config.h: take LAME's own template and switch on only what a 64-bit Android/desktop build has (no decoder, no assembler).
awk '
BEGIN {
  n = split("HAVE_ERRNO_H HAVE_FCNTL_H HAVE_INT16_T HAVE_INT32_T HAVE_INT64_T HAVE_INT8_T HAVE_INTTYPES_H HAVE_LIMITS_H HAVE_MEMORY_H HAVE_STDINT_H HAVE_STDLIB_H HAVE_STRINGS_H HAVE_STRING_H HAVE_STRTOL HAVE_SYS_STAT_H HAVE_SYS_TIME_H HAVE_SYS_TYPES_H HAVE_UINT16_T HAVE_UINT32_T HAVE_UINT64_T HAVE_UINT8_T HAVE_UNISTD_H STDC_HEADERS TIME_WITH_SYS_TIME", on, " ")
  for (i = 1; i <= n; i++) val[on[i]] = "1"
  val["SIZEOF_DOUBLE"] = 8; val["SIZEOF_FLOAT"] = 4; val["SIZEOF_INT"] = 4; val["SIZEOF_LONG"] = 8
  val["SIZEOF_LONG_LONG"] = 8; val["SIZEOF_SHORT"] = 2; val["SIZEOF_UNSIGNED_INT"] = 4
  val["SIZEOF_UNSIGNED_LONG"] = 8; val["SIZEOF_UNSIGNED_LONG_LONG"] = 8; val["SIZEOF_UNSIGNED_SHORT"] = 2
}
/^#undef / { if ($2 in val) { print "#define " $2 " " val[$2]; next } }
{ print }
' "$SRC/config.h.in" > "$WORK/config.h"
FILES=$(ls "$SRC"/libmp3lame/*.c | grep -v mpglib_interface)
COMMON="-O2 -fPIC -DHAVE_CONFIG_H -DLAME_LIBRARY_BUILD -DUSE_FAST_LOG=0 -I$WORK -I$SRC/include -I$SRC/libmp3lame -I$SRC -w"
build() { # abi clang-prefix extra-link
  local abi="$1" cc="$2" ; shift 2
  mkdir -p "$HERE/out/$abi"
  # shellcheck disable=SC2086
  "$cc" $COMMON -shared -fvisibility=hidden -o "$HERE/out/$abi/libsuperpotli_mp3.so" "$HERE/superpotli_mp3_jni.c" $FILES "$@" -lm
  [ "$abi" = host ] || "$TOOLS/bin/llvm-strip" --strip-unneeded "$HERE/out/$abi/libsuperpotli_mp3.so"
}
if [ "${1:-}" = host ]; then
  mkdir -p "$WORK/jni" && cp "$TOOLS/sysroot/usr/include/jni.h" "$WORK/jni/"   # only jni.h from the NDK, for the desktop test copy
  COMMON="$COMMON -I$WORK/jni"
  build host clang
  exit 0
fi
build arm64-v8a "$TOOLS/bin/aarch64-linux-android26-clang" -Wl,-z,max-page-size=16384 -Wl,--gc-sections -Wl,-soname,libsuperpotli_mp3.so
build x86_64 "$TOOLS/bin/x86_64-linux-android26-clang" -Wl,-z,max-page-size=16384 -Wl,--gc-sections -Wl,-soname,libsuperpotli_mp3.so
echo "Built: $HERE/out/arm64-v8a and $HERE/out/x86_64. Copy them to android/app/src/main/jniLibs/<abi>/ to ship."
