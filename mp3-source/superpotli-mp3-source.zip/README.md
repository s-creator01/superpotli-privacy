# SuperPotli MP3 encoder: source and build steps (LGPL)

This folder is the **complete corresponding source** of the shared library `libsuperpotli_mp3.so` that SuperPotli loads to save MP3 files (Convert Audio and Extract Audio). It is offered under the GNU Lesser General Public License (LGPL, version 2 or later), the licence of LAME. The rest of the SuperPotli app is NOT covered by this offer; it stays closed source ("All rights reserved") and only calls this library through four functions.

## What is in the library
1. **LAME 3.100**, the open-source MP3 encoder (https://lame.sourceforge.io). The source we built from is in `source/lame-3.100.tar.gz` (SHA-256 in `source/lame-3.100.tar.gz.sha256`). It is the LAME 3.100 snapshot published as `ffmpegwasm/lame` commit `2badea1974ae36cb8312afe99cff1e6b3b5decee` (copy kept by the owner in another project). We did not modify any LAME file. The official release tarball is at https://sourceforge.net/projects/lame/files/lame/3.100/.
2. **The bridge** `superpotli_mp3_jni.c` (about 130 lines, Copyright (c) 2026 S Projects, LGPL 2 or later): four functions the app calls (`nativeInit`, `nativeEncode`, `nativeFlush`, `nativeClose`) and a plain C layer (`sp_mp3_open/encode/flush/close`). Re-created on 2026-11-26 because the original bridge file was lost; the interface is identical to the one the app's Kotlin code (`Mp3Lame.kt`) always used.
3. `build-android.sh`: builds the library for `arm64-v8a` and `x86_64` with the Android NDK (r28 used).
4. `COPYING.LGPL`: the licence text.
5. `test_sp_mp3.c`: a small test program (no Java needed).

## Rebuild it yourself (this also lets you replace the library with your own build)
1. Install the Android NDK (any recent r2x).
2. Run `./build-android.sh` (it checks the LAME checksum, builds both CPU types, applies 16 KB page alignment and strips symbols). Output: `out/arm64-v8a/libsuperpotli_mp3.so` and `out/x86_64/libsuperpotli_mp3.so`.
3. To use your build, put the two files into the app project at `android/app/src/main/jniLibs/<abi>/` and rebuild the app. The app finds the library by the name `superpotli_mp3` and needs no other change. (An installed Play app cannot be changed in place; the LGPL right to replace the library is met by providing this source and these steps.)
4. Desktop test copy: `./build-android.sh host`, then `clang -o test_sp_mp3 test_sp_mp3.c && ./test_sp_mp3 out/host/libsuperpotli_mp3.so /tmp`. The two MP3 files it writes (mono 44.1 kHz 128 kbit/s and stereo 48 kHz 192 kbit/s) should play and report those values in `ffprobe`.

## How this build was checked (2026-11-26)
- NDK 28.2.13676358, LAME checksum OK, both ABIs built; LOAD segment alignment 0x4000 (16 KB) for both; the same four `Java_..._Mp3Lame_native*` symbols and the same system libraries (`libm`, `libdl`, `libc`) as the library it replaces.
- Desktop test and the arm64 library on the Android emulator (arm64-v8a): `test_sp_mp3` wrote valid MP3 files (`ffprobe`: mp3, 44100 Hz mono 128000 bit/s and 48000 Hz stereo 192000 bit/s, about 3 s).
- JNI path on the emulator: a small Java class with the same package, class and method signatures as `Mp3Lame` loaded the library through `app_process` and used the same call pattern as `AudioEngine.encodeMp3` (chunks of 73,728 frames, flush, close); output valid MP3 (mono and stereo, 44100 Hz, 128000 bit/s, 2 s).
- NOT done: the x86_64 library was built and inspected but not run; an MP3 export inside the installed app is not yet re-checked (needs a new APK).
- The library it replaces (`launch/archive/mp3-old-so/`, SHA-256 `e7a40a08...` arm64 and `76e6b927...` x86_64) was built from an unknown LAME 3.100 source with a lost bridge; do not ship it again.
