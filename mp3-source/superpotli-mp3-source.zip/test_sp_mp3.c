/* Test program (no Java): loads libsuperpotli_mp3.so with dlopen, encodes 3 seconds of a 440 Hz tone (mono and stereo)
 * through the exported sp_mp3_* functions and writes MP3 files. Usage: test_sp_mp3 /path/to/libsuperpotli_mp3.so outdir */
#include <dlfcn.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

typedef void *(*open_fn)(int, int, int);
typedef int (*enc_fn)(void *, const short *, int, unsigned char *, int);
typedef int (*flush_fn)(void *, unsigned char *, int);
typedef void (*close_fn)(void *);

static int run(void *lib, const char *path, int rate, int ch, int kbps) {
    open_fn open_ = (open_fn)dlsym(lib, "sp_mp3_open");
    enc_fn enc = (enc_fn)dlsym(lib, "sp_mp3_encode");
    flush_fn flush = (flush_fn)dlsym(lib, "sp_mp3_flush");
    close_fn close_ = (close_fn)dlsym(lib, "sp_mp3_close");
    if (!open_ || !enc || !flush || !close_) { fprintf(stderr, "missing symbol\n"); return 2; }
    void *e = open_(rate, ch, kbps);
    if (!e) { fprintf(stderr, "open failed\n"); return 3; }
    FILE *f = fopen(path, "wb");
    if (!f) return 4;
    int total = rate * 3, chunk = 1152 * 8;
    short *pcm = malloc(sizeof(short) * chunk * 2);
    unsigned char *out = malloc(chunk * 2 + 20000);
    int pos = 0;
    while (pos < total) {
        int n = total - pos < chunk ? total - pos : chunk;
        for (int i = 0; i < n; i++) {
            short v = (short)(12000.0 * sin(2.0 * M_PI * 440.0 * (pos + i) / rate));
            if (ch == 1) pcm[i] = v; else { pcm[2 * i] = v; pcm[2 * i + 1] = v; }
        }
        int w = enc(e, pcm, n, out, chunk * 2 + 20000);
        if (w < 0) { fprintf(stderr, "encode failed\n"); return 5; }
        fwrite(out, 1, w, f);
        pos += n;
    }
    int w = flush(e, out, chunk * 2 + 20000);
    if (w > 0) fwrite(out, 1, w, f);
    fclose(f);
    close_(e);
    if (open_(7000, 2, 128) != NULL || open_(44100, 2, 9999) != NULL) { fprintf(stderr, "bad arguments accepted\n"); return 6; }
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) return 1;
    void *lib = dlopen(argv[1], RTLD_NOW);
    if (!lib) { fprintf(stderr, "dlopen: %s\n", dlerror()); return 1; }
    char p[1024];
    snprintf(p, sizeof p, "%s/mono_44100_128.mp3", argv[2]);
    int r = run(lib, p, 44100, 1, 128);
    if (r) return r;
    snprintf(p, sizeof p, "%s/stereo_48000_192.mp3", argv[2]);
    r = run(lib, p, 48000, 2, 192);
    if (r) return r;
    puts("OK");
    return 0;
}
